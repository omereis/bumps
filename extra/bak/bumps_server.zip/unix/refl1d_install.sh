sudo pip install matplotlib
sudo pip install scipy
sudo apt install -y libgstreamer1.0-0 gstreamer1.0-plugins-base gstreamer1.0-plugins-good gstreamer1.0-plugins-bad gstreamer1.0-plugins-ugly gstreamer1.0-libav gstreamer1.0-doc gstreamer1.0-tools gstreamer1.0-x gstreamer1.0-alsa gstreamer1.0-gl gstreamer1.0-gtk3 gstreamer1.0-qt5 gstreamer1.0-pulseaudio
sudo apt install -y freeglut3-dev
sudo apt install -y libwebkitgtk-1.0-0
sudo apt install -y libjpeg-dev zlib1g-dev libpng-dev libtiff-dev libsdl-dev libnotify-dev libsm-dev
sudo pip install -U -f https://extras.wxpython.org/wxPython4/extras/linux/gtk3/ubuntu-16.04 wxPython
sudo pip install refl1d


