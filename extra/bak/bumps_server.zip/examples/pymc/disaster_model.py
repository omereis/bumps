from bumps.pymcfit import PyMCProblem
from pymc.examples import disaster_model as model
problem = PyMCProblem(model)
