const ServerCommands = {
    START_FIT   : 'StartFit',
    DELETE      : 'Delete',
    GET_DATA    : 'GetData',
    GET_STATUS  : 'GetStatus',
    PRINT_STATUS: 'print_status',
    GET_RESULTS : 'get_results'
};

