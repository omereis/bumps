#!/usr/bin/env python
# -*- coding: utf-8 -*-
from .get_host_port import get_host_port
if __name__ == '__main__':
    host, port = get_host_port()
