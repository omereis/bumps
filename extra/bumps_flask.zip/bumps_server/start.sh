python bumps_ws_server.py --host 0.0.0.0 --port 5678

