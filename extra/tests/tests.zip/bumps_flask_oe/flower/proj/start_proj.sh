celery worker start w1 -A proj -l info
