celery -A bumps_flask.celery_bumps worker -E -l info
