celery -A celery_bumps worker -E -l info
