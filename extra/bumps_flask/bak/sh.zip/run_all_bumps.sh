#!/bin/bash
echo "Welcome"
./servers_run.sh
./worker_run.sh
./flower_run.sh
./bumps_run.sh
